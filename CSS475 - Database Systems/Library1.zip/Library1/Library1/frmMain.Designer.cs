﻿namespace Library1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.library1DataSet = new Library1.Library1DataSet();
            this.btnAddNum = new System.Windows.Forms.Button();
            this.TextLID = new System.Windows.Forms.TextBox();
            this.lstLib = new System.Windows.Forms.ListBox();
            this.lstTop = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstLibID = new System.Windows.Forms.ListBox();
            this.TextID = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnUpdate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lstGenre = new System.Windows.Forms.ListBox();
            this.lstTrans = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lstActor = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.library1DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // library1DataSet
            // 
            this.library1DataSet.DataSetName = "Library1DataSet";
            this.library1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnAddNum
            // 
            this.btnAddNum.Location = new System.Drawing.Point(12, 21);
            this.btnAddNum.Name = "btnAddNum";
            this.btnAddNum.Size = new System.Drawing.Size(75, 32);
            this.btnAddNum.TabIndex = 0;
            this.btnAddNum.Text = "AddLib";
            this.btnAddNum.UseVisualStyleBackColor = true;
            this.btnAddNum.Click += new System.EventHandler(this.btnAddNum_Click);
            // 
            // TextLID
            // 
            this.TextLID.Location = new System.Drawing.Point(158, 118);
            this.TextLID.Name = "TextLID";
            this.TextLID.Size = new System.Drawing.Size(66, 26);
            this.TextLID.TabIndex = 1;
            this.TextLID.Text = "LName";
            // 
            // lstLib
            // 
            this.lstLib.FormattingEnabled = true;
            this.lstLib.ItemHeight = 20;
            this.lstLib.Location = new System.Drawing.Point(12, 101);
            this.lstLib.Name = "lstLib";
            this.lstLib.Size = new System.Drawing.Size(120, 104);
            this.lstLib.TabIndex = 2;
            // 
            // lstTop
            // 
            this.lstTop.FormattingEnabled = true;
            this.lstTop.ItemHeight = 20;
            this.lstTop.Location = new System.Drawing.Point(447, 50);
            this.lstTop.Name = "lstTop";
            this.lstTop.Size = new System.Drawing.Size(341, 104);
            this.lstTop.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(443, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Top Rated Books With Rating > 7";
            // 
            // lstLibID
            // 
            this.lstLibID.FormattingEnabled = true;
            this.lstLibID.ItemHeight = 20;
            this.lstLibID.Location = new System.Drawing.Point(12, 250);
            this.lstLibID.Name = "lstLibID";
            this.lstLibID.Size = new System.Drawing.Size(120, 84);
            this.lstLibID.TabIndex = 5;
            // 
            // TextID
            // 
            this.TextID.Location = new System.Drawing.Point(245, 118);
            this.TextID.Name = "TextID";
            this.TextID.Size = new System.Drawing.Size(57, 26);
            this.TextID.TabIndex = 6;
            this.TextID.Text = "LID";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 32);
            this.button1.TabIndex = 7;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Library Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(154, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(241, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "ID";
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Location = new System.Drawing.Point(201, 21);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(77, 32);
            this.BtnUpdate.TabIndex = 12;
            this.BtnUpdate.Text = "Update";
            this.BtnUpdate.UseVisualStyleBackColor = true;
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Library ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(443, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Action Movies";
            // 
            // lstGenre
            // 
            this.lstGenre.FormattingEnabled = true;
            this.lstGenre.ItemHeight = 20;
            this.lstGenre.Location = new System.Drawing.Point(447, 208);
            this.lstGenre.Name = "lstGenre";
            this.lstGenre.Size = new System.Drawing.Size(120, 84);
            this.lstGenre.TabIndex = 16;
            // 
            // lstTrans
            // 
            this.lstTrans.FormattingEnabled = true;
            this.lstTrans.ItemHeight = 20;
            this.lstTrans.Location = new System.Drawing.Point(832, 60);
            this.lstTrans.Name = "lstTrans";
            this.lstTrans.Size = new System.Drawing.Size(120, 84);
            this.lstTrans.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(828, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(208, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "Borrower Halla Has 2 Books";
            // 
            // lstActor
            // 
            this.lstActor.FormattingEnabled = true;
            this.lstActor.ItemHeight = 20;
            this.lstActor.Location = new System.Drawing.Point(607, 208);
            this.lstActor.Name = "lstActor";
            this.lstActor.Size = new System.Drawing.Size(120, 84);
            this.lstActor.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(607, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(214, 20);
            this.label8.TabIndex = 22;
            this.label8.Text = "Number of Actors in Movie Mi";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1541, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lstActor);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lstTrans);
            this.Controls.Add(this.lstGenre);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnUpdate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TextID);
            this.Controls.Add(this.lstLibID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstTop);
            this.Controls.Add(this.lstLib);
            this.Controls.Add(this.TextLID);
            this.Controls.Add(this.btnAddNum);
            this.Name = "frmMain";
            this.Text = "Library1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.library1DataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Library1DataSet library1DataSet;
        private System.Windows.Forms.Button btnAddNum;
        private System.Windows.Forms.TextBox TextLID;
        private System.Windows.Forms.ListBox lstLib;
        private System.Windows.Forms.ListBox lstTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstLibID;
        private System.Windows.Forms.TextBox TextID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnUpdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstGenre;
        private System.Windows.Forms.ListBox lstTrans;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox lstActor;
        private System.Windows.Forms.Label label8;
    }
}

